
export interface NotificationType {
  id: number;
  title: string;
  content: string;
  create_date: number;
  expiry_date: number;
  status: string;
}
