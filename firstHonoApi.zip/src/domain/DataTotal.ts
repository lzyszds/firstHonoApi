export interface DataTotal<T> {
    total: number,
    data: T[],
}